// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>


//CHANGED: Created function to detect and prevent buffer overflow
static bool bufferCheck(const std::string aNum, char *uInput, int bufSizeLimit){

  //Variable to copy user input to a null-terminated one
  char *uInputCopy = new char [bufSizeLimit + 1];

  //copy userInput into a separate variable for sanitation
  char * copiedUserInput = std::strcpy(uInputCopy, uInput);

  //variable to hold acount_number parameter
  char copiedAccNum[bufSizeLimit];

  //for loop to place account_number into char{}
  for(int i = 0; i < bufSizeLimit; i++){
    copiedAccNum[i] = aNum[i];
  }

  //if statement for bound check
  if(sizeof(copiedUserInput) > sizeof(copiedAccNum) || strcmp(copiedAccNum, copiedUserInput) != 0){
    std::cout << "Buffer Overflow Detected! Aborting...";
    abort();
  }else{
    return true;
  }
}

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_order
  //  varaible, and its position in the declaration. It must always be directly before the variable used for input.

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";
  std::cin >> user_input;
  
  //CHANGED: Call to bufferCheck function with account_number and user_input as parameters
  bool buffCheck = bufferCheck(account_number, user_input, sizeof(user_input));
  
  //CHANGED: Placed std::cout's in and if statement 
  if(buffCheck){
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
  }

  //CHANGED: Added a return statement
  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
