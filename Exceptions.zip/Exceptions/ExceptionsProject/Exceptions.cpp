// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//CHANGED: Added the <exception> and <string> include and a custom exception class
#include <exception>
#include <string>

//Custom Exception 
class CustomExeption : public std::exception{
    public: 
        //Custom string to display when what() is called
        const std::string custEx = "Error: Custom Exception Error Message";
        const char * what () {
            return (custEx).c_str();
        }
        
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  //CHANGED: Added standard exception
  throw std::logic_error("Logical Error Exception");

  return true;
}
void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  //CHANGED: Changed if statement to a try block
  try{
    do_even_more_custom_application_logic();
    
    std::cout << "Even More Custom Application Logic Succeeded." << std::endl; 

    //Throws custom exception
    throw CustomExeption();
  }
  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main

  //CHANGED: Added catch block
  catch(CustomExeption ce){
    std::cout << "Custom STD Exception Caught" << std::endl;
    std::cout << ce.what() << std::endl;

  }
  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception

  //CHANGED: Added  an if statement to throw an error if "den" is zero
  if(den == 0){
    return 0;
    throw std::invalid_argument("Error: Denominator can not be zero");
    
  }else{
    //CHANGED: Moved return statement into else block
    return (num / den);
  }
  
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;

  auto result = divide(numerator, denominator);

  //CHANGED: Moved "result" into try block
  //CHANGED: Created if statement to catch the if error is thrown
  
  try
  {
    if(result == 0){
      throw std::invalid_argument("Exception Thrown: Invalid Argument");
    }else{
      std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
  }
  catch(std::invalid_argument& ia)
  {
    std::cerr << ia.what() << '\n';
  }

  //std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;

 
}

int main()
{

  
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception 
  //  that wraps the whole main function, and displays a message to the console.
  
  //CHANGED: Wrapped function in in try catch blocks
  try{
    do_division();
  }
  catch(CustomExeption& ce){
    std::cout << "Custom Exception Caught: " << std::endl;
    std::cout << ce.what() << std::endl;
  }
  catch(std::exception& exName){
    std::cout << " Exception Caught" << std::endl;
    std::cout << exName.what() << std::endl;
  }
  catch(const std::uncaught_exceptions& ue){
    std::cout << "Uncaught Exception Caught: " << std::endl;
    std::cout << ue.what() << std::endl;
  }
  
  try{
    do_custom_application_logic();
  }
  catch(CustomExeption& ce){
    std::cout << "Custom Exception Caught: " << std::endl;
    std::cout << ce.what() << std::endl;
  }
  catch(std::exception& exName){
    std::cout << " Exception Caught" << std::endl;
    std::cout << exName.what() << std::endl;
  }
  catch(const std::uncaught_exception& ue){
    std::cout << "Uncaught Exception Caught: " << std::endl;
    std::cout << ue.what() << std::endl;
  }
  
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
